const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');

const client = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    console.log("Request Event: ", event);

    const requestOrigin = event?.headers?.origin || event?.headers?.Origin;
    const allowedOrigins = new Set([
        'http://localhost:5173',
        'http://127.0.0.1:5173',
    ]);
    const allowOriginHeader = allowedOrigins.has(requestOrigin) ? requestOrigin : 'http://localhost:5173';

    // 1. Define standard CORS headers
    const headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": allowOriginHeader,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, X-Amz-Date, Authorization, X-Api-Key, X-Amz-Security-Token",
        "Vary": "Origin",
    };

    // 2. Handle the Preflight (OPTIONS) request immediately
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: headers,
            body: JSON.stringify({ message: "CORS Preflight Successful" }),
        };
    }

    let body;
    let statusCode = 200;

    try {
        const path = event.resource; // e.g., /auth/signup or /auth/login
        const httpMethod = event.httpMethod;

        // 3. Enforce POST for actual logic
        if (httpMethod !== 'POST') {
            statusCode = 405;
            throw new Error(`Method "${httpMethod}" not allowed`);
        }

        const requestJSON = JSON.parse(event.body || "{}");
        const { email, password, username } = requestJSON;

        if (!email || !password) {
            statusCode = 400;
            throw new Error("Missing email or password");
        }

        // --- SIGNUP LOGIC ---
        if (path === '/auth/signup') {
            const existingUser = await dynamo.send(new GetCommand({
                TableName: process.env.USERS_TABLE,
                Key: { email }
            }));

            if (existingUser.Item) {
                statusCode = 400;
                throw new Error("User already exists");
            }

            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);

            await dynamo.send(new PutCommand({
                TableName: process.env.USERS_TABLE,
                Item: {
                    email,
                    username: username || email.split('@')[0],
                    password: hashedPassword,
                    createdAt: new Date().toISOString()
                }
            }));

            body = { message: "User created successfully" };

            // --- LOGIN LOGIC ---
        } else if (path === '/auth/login') {
            const response = await dynamo.send(new GetCommand({
                TableName: process.env.USERS_TABLE,
                Key: { email }
            }));

            const user = response.Item;

            if (!user) {
                statusCode = 401;
                throw new Error("Invalid credentials");
            }

            const isValidPassword = await bcrypt.compare(password, user.password);

            if (!isValidPassword) {
                statusCode = 401;
                throw new Error("Invalid credentials");
            }

            // Simple token (Use JWT for production)
            const token = Buffer.from(`${email}-${Date.now()}`).toString('base64');

            body = {
                message: "Login successful",
                token,
                user: { email: user.email, username: user.username }
            };

        } else {
            statusCode = 404;
            throw new Error(`Path not found: "${path}"`);
        }

    } catch (err) {
        console.error("Handler Error:", err);
        // If statusCode wasn't explicitly set to 4xx, default to 500
        statusCode = (statusCode >= 400) ? statusCode : 500;
        body = { error: err.message || "Internal server error" };
    }

    // 4. Always return the headers with the response
    return {
        statusCode,
        headers,
        body: JSON.stringify(body)
    };
};