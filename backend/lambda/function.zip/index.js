const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    console.log("Request Event: ", event);

    let body;
    let statusCode = 200;
    const headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
    };

    try {
        switch (event.httpMethod) {
            case 'GET':
                body = await dynamo.send(new ScanCommand({ TableName: process.env.TABLE_NAME }));
                body = body.Items;
                break;
            case 'POST':
                let requestJSON = JSON.parse(event.body);
                await dynamo.send(new PutCommand({
                    TableName: process.env.TABLE_NAME,
                    Item: {
                        id: requestJSON.id || Date.now().toString(),
                        ...requestJSON
                    }
                }));
                body = `Put item ${requestJSON.id}`;
                break;
            default:
                throw new Error(`Unsupported route: "${event.httpMethod}"`);
        }
    } catch (err) {
        statusCode = 400;
        body = err.message;
    } finally {
        body = JSON.stringify(body);
    }

    return { statusCode, body, headers };
};
